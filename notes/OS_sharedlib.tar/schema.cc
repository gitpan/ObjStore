#include <ostore/ostore.hh>
#include <ostore/manschem.hh>
#include "main.hh"

OS_MARK_SCHEMA_TYPE(testing);
