#include <ostore/ostore.hh>

// container class for Class T
template <class T>
class Foo {
public:
 int get_id ();
 char *get_database();
 char *get_rootname();
 T get_object();
 int delete_object();
 int replace_object(T);
 Foo(int x=0, char* s1= "DefaultDB",char *s2 = "MyRoot");
 ~Foo();
 static void initialize();

private:
 int id;
 char *database_name;
 char *rootname;
 os_reference cont_obj;
 static os_typespec* thetype; 
 os_database *db;
};

