#include "slib.hh"
#include <iostream.h>
#include "main.hh"

int main(){

 cout << "beginning main" << endl;
 Foo<testing>::initialize();
 Foo<testing>  a(3,"TestDB");
 cout << "Object created with id " << a.get_id() << " in database "<< a.get_database() <<" and type's value " << a.get_object().x << endl;
 testing T1(400);
 a.replace_object(T1);
 cout << "Object created with id " << a.get_id() << " in database "<< a.get_database() <<" and type's value " << a.get_object().x << endl;

 return 1;
}

