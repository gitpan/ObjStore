#include <ostore/ostore.hh>

class testing {
public:
 int x;
 testing(int i = 0){x = i;}
 static os_typespec* get_os_typespec();
};
